console.debug("My awesome module");
